s = "Opera: "
for k, v in pairs(Opera) do
 s = s..k.." "
end
print(s)
--print(package.path)
require "1"
require "2"
require "3"

