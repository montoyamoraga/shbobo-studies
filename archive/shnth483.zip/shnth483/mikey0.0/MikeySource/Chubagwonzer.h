class Gwonzero : public Component {
 private:
  signed char vale;
 public:
 Gwonzero(): vale(0) {
 }
 void paint(Graphics &g) {
  g.setColour (Colours::green);
  int yc = getHeight()/2;
  int yh = vale * getHeight()/ 256;
  if (vale > 0) 
   g.fillRect (0,yc-yh, getWidth(), yh);
  else 
   g.fillRect (0,yc, getWidth(), -yh);
 }
 void setVale(signed char v) {
  vale = v; repaint();
 }
};

class Chubagwonzer : public Chub, public Thread, public Component, public Timer  {
 private:
  //Label gwonzers[8];
  Gwonzero gwonzers[8];
  bool muticio;  
  CriticalSection muticon;
  String conker;
 public:
  static DocumentWindow * dw;
 Chubagwonzer(): Thread("GwonzerThread") {
  muticio = false;
  conker = "pos";
  setSize(400,100);
  for (int i = 0; i < 8; i++) {
   //gwonzers[i] = Gwonzero();
   addAndMakeVisible(&gwonzers[i]);
  }
  startThread();
  startTimer (20);
 }
 ~Chubagwonzer(){ wait(100); stopThread(100); chubCLOZ();}
 bool chubShouldEnd() { return threadShouldExit(); }
 void run() { 
 // while (!chubShouldEnd()) { chubCALL(); }
  chubOPEN();
  chubRUN(); 
  printf("stopt\n");
 } 
 void resized() {
  for (int i = 0; i < 8; i++) 
   gwonzers[i].setBounds(getWidth()*i/8,0,getWidth()/8,getHeight());
 }
 void timerCallback () {
  for (int i = 0; i < 8; i++) 
    gwonzers[i].setVale(gwonz[i]);
 }
 void chubCALL() {
  //if (muticon.tryEnter()) { //muticio = true;
   //for (int i = 0; i < 8; i++) 
   // gwonzers[i].setVale(gwonz[i]);
   //wait(20);
  //muticon.exit();}
 }
 static void showGwonz() {
  //DialogWindow::LaunchOptions launchOptions;
  //Chubagwonzer * chb = new Chubagwonzer();
	 //if (dw) return;
	 
		Chubagwonzer  chb;// = new Chubagwonzer();
	 //dw = new DocumentWindow("Spit Gwonz", Colours::black,7,true);
	 //dw->setVisible(true);
	 //dw->setContentOwned(chb,true);
   DialogWindow::showModalDialog ("Spit Gwonz", &chb,
                            nullptr, Colours::black, true, true, true);
  //chb.stopThread(20);
  //chb.chubCLOZ();
  //delete(chb);
  /*launchOptions.dialogTitle = ("Spit Gwonz");
  launchOptions.escapeKeyTriggersCloseButton = true;
  launchOptions.resizable = true;
  launchOptions.useNativeTitleBar = false;
  launchOptions.useBottomRightCornerResizer = true;
  launchOptions.componentToCentreAround = nullptr;
  launchOptions.content.setOwned(new Chubagwonzer());
  launchOptions.content->setSize(640, 480);
  //launchOptions.launchAsync();
  //launchOptions.create();
  if (!dag) dag = launchOptions.launchAsync();*/
	}
};

class GwonzerWindow : public DocumentWindow {
 private: Chubagwonzer chb;
public: 
	GwonzerWindow() : DocumentWindow("SpitGwonz", Colours::black,7,true) {
		setVisible(true);
		setResizable(true,true);
		setContentOwned(&chb,true);
	}
	~GwonzerWindow(){}
	void closeButtonPressed 	( 		); 
};
		
		
		
 GwonzerWindow * gw = nullptr;
void GwonzerWindow::closeButtonPressed () {
	delete(this); gw = nullptr;
}

 /* void Chubagwonzer::showGwonz() {
	if (gw) return;
	else gw = new GwonzerWindow();
} */
