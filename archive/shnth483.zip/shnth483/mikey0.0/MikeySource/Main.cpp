//#include "chub.h"
#include <stdio.h>
#include <string.h>
#include "chub.h"
#include <stdio.h>
#include <string.h>

#include "../JuceLibraryCode/JuceHeader.h"
//using juce::Point;
class Chubagwonzer : public Chub, public Thread  {
 private:
 public:
 Chubagwonzer(): Thread("GwonzerThread") {
  startThread();
 }
 ~Chubagwonzer(){ wait(100); stopThread(100); chubCLOZ();}
 bool chubShouldEnd() { return threadShouldExit(); }
 void run() { 
  chubOPEN();
  chubRUN(); 
 } 
};

class MikeyFart : public AudioIODeviceCallback {
 protected:
  int oscil; bool gwonz;
 public:
 void audioDeviceIOCallback (const float **inputChannelData, 
  int numInputChannels, 
  float **outputChannelData, 
  int numOutputChannels, 
  int numSamples) {
   for (int i = 0; i < numSamples; i++) {
    if (gwonz) oscil++;
    else oscil--;
    if (oscil>800) gwonz = false;
    if (oscil<-800) gwonz = true;
    for (int j = 0; j < numOutputChannels; j++)
     outputChannelData[j][i] = oscil;
   }
  }
 void audioDeviceAboutToStart (AudioIODevice *device){}
 void audioDeviceStopped (){}
};


class MikeyOrgano : public Image {
 public:
 MikeyOrgano() : Image(Image::ARGB,100,100,true) {
  for (int i = 0; i < 10000; i++) corpusculate();
 }
 void corpusculate() {
  int widochub = getWidth()/2;
  int hidochub = getHeight()/2;
	 juce::Point<int> mast(getWidth()/2,getHeight()/2);
  juce::Point<int> vein(rand()%getWidth(),rand()%getHeight());
  
  if (vein.getDistanceFrom(mast) < widochub) {
   Colour col ((uint8)rand(),(uint8)rand(),(uint8)rand(),(uint8)255);
   setPixelAt(vein.x, vein.y, col);
   //interpolatedWith (getPixelAt
  }
 }
 void heal() {
  juce::Point<int> mast(getWidth()/2,getHeight()/2);
  juce::Point<int> vein(rand()%getWidth(),rand()%getHeight());
  if (vein.getDistanceFrom(mast) < getWidth()/2) {
   Colour organ = getPixelAt(vein.x,vein.y);
   for (int i = 0; i < 20; i++) {
    juce::Point<int> pii = vein.getPointOnCircumference (0.2*i,0.2*i).toInt();
    setPixelAt(pii.x,pii.y,getPixelAt(pii.x,pii.y).interpolatedWith(organ,20.0/i));
   }
  }
 }
};

class Puncher : public Image {
 public:
 Puncher () : Image(Image::ARGB,20,20,true) {
  Graphics g (*this);
  g.setColour (Colours::ivory);
  g.fillEllipse (0,0,getWidth(),getHeight());
 } 
 juce::Point<int> getCentroid() {
  return Point<int>(getWidth()/2,getHeight()/2);
 }
};

class Toonhand : public Component {
 public:
 Toonhand () {
  setSize(20,20);
 }
 void paint (Graphics &g) {
  g.setColour(Colours::ivory);
  g.fillEllipse 	(0,0,getWidth(),getHeight());
 }
 void setCentre(juce::Point<int> ip) {
  setTopLeftPosition(ip.x-getWidth()/2,ip.y-getHeight()/2);
 }
};
const float  PI_F=3.14159265358979f;
class MikeyW : public Component, public Timer {
 MikeyOrgano mo;
 //Toonhand left,rite;
 juce::Point<int> lefto;
 juce::Point<int> rihto;
 Puncher left,rite;
 public:
 MikeyW() : Component () {
  startTimer(10);
  setSize (200,200);//mo.getWidth(),mo.getHeight());
  //addAndMakeVisible(&left);
  //addAndMakeVisible(&rite);
 }
 void timerCallback ()  {
  mo.heal();
  repaint();
  //printf("timor\n");
 }
 void paintOverChildren (Graphics &g) {
  //g.setColour(Colours::black);
  //g.fillRect(0,0,10,10);
  g.drawImageAt (mo,50,50);
  g.drawImageAt (left,(lefto-left.getCentroid()).x,(lefto-left.getCentroid()).y);
  g.drawImageAt (left,(rihto-left.getCentroid()).x,(rihto-left.getCentroid()).y);
 }
 void punch(signed char l, signed char r) {
  juce::Point<int> centro( getWidth()/2,getHeight()/2);
  lefto = centro.getPointOnCircumference(60,PI_F*l/256.0-PI_F/2).toInt();
  rihto = centro.getPointOnCircumference(60,PI_F/2-PI_F*r/256.0).toInt();
  //left.setCentre(lefto);
  //rite.setCentre(rihto);
 }
	void setCentre(juce::Point<int> ip) {
		setTopLeftPosition(ip.x-getWidth()/2,ip.y-getHeight()/2);
	}
};

class MikeySquart : public AudioSource , public Chubagwonzer {
 protected:
  int oscil; bool gwonk;
  signed char lastg[2];
 public:
 void prepareToPlay (int samplesPerBlockExpected, 
  double sampleRate){}
 void 	releaseResources (){}
 void 	getNextAudioBlock (const AudioSourceChannelInfo &bufferToFill){
  AudioSampleBuffer * buffer = bufferToFill.buffer;
  int startus = bufferToFill.startSample;
  int numsamp = bufferToFill.numSamples;
  for (int i = startus; i < startus+numsamp; i++) {
   if (gwonk) oscil++;
   else oscil--;
   if (oscil>180) gwonk = false;
   if (oscil<-180) gwonk = true;
   for (int j = 0; j < buffer->getNumChannels(); j++)
    buffer->getSampleData(j)[i]= oscil;//* gwonz[j];
  } 
  buffer->applyGainRamp (0,startus,numsamp,lastg[0],gwonz[0]);
  buffer->applyGainRamp (1,startus,numsamp,lastg[3],gwonz[3]);
  lastg[0]=gwonz[0];lastg[3]=gwonz[3]; puncho(gwonz[0],gwonz[3]);
 }
 virtual void puncho(signed char l, signed char r) {}
};



class Landscape : public Component, public MikeySquart, public Timer {
 MikeyW mw;
 public:
 Landscape() {
  addAndMakeVisible(&mw);
  repaint();
  resized();
  //startTimer(10);
  //setSize (100,100);//mo.getWidth(),mo.getHeight());
 }
 void timerCallback ()  {
  mw.punch(gwonz[0],gwonz[3]);
  //printf("timor\n");
 }
 void puncho(signed char l, signed char r) {
  mw.punch(l,r);
 }
 void resized() {
	 mw.setCentre(juce::Point<int>(getWidth()/2,getHeight()/2));
 }
 void paint (Graphics &g) {
  //g.setColour(Colours::blue);
  //g.fillRect(0,0,10,10);
 }
};

class MikeyWindow  : public DocumentWindow {
public:
 AudioDeviceManager adm;//()
 Landscape lander;
 MikeyWindow() : DocumentWindow ("Mikey by Shbobo",
      Colours::forestgreen, DocumentWindow::allButtons,
      true) {
 String pronk = adm.initialise (0,2,nullptr,true);
 if (pronk.isEmpty()) {
  printf("soundo\n");
  //adm.addAudioCallback 	(new MikeyFart());
  AudioSourcePlayer * asp = new AudioSourcePlayer();
  ReverbAudioSource * ras = new ReverbAudioSource(&lander,true);////
  //ReverbAudioSource * ras = new ReverbAudioSource(new MikeySquart(),true);
  Reverb::Parameters rep; rep.roomSize = 1.0;
  rep.wetLevel = 1.0;
  rep.width = 1.0;
  ras->setParameters 	(rep);
  asp->setSource(ras);
  asp->setGain(1.0/8000.0); 
  adm.addAudioCallback 	(asp);
 }
 setContentOwned(&lander,true);
 setResizable(true, true);
 centreWithSize (400,400);
 setVisible (true);
 }
 ~MikeyWindow() {}
 
 void closeButtonPressed() {
  JUCEApplication::quit();
  //delete(this);
 }
};

class Mikey : public JUCEApplication {
public:
 MikeyWindow* mw;
 Mikey(){}
 ~Mikey(){}
 void initialise (const String& commandLine) {
   mw = new MikeyWindow();
 }
 void shutdown() {
  //jj = 0; //tt = 0;
 }
 const String getApplicationName() {
  return "Mikey by Shbobo";
 }
 const String getApplicationVersion() {
  return ProjectInfo::versionString;
 }
 bool moreThanOneInstanceAllowed() {
  return false;
 }
 void anotherInstanceStarted (const String& commandLine) {}
private:
};

START_JUCE_APPLICATION (Mikey)

