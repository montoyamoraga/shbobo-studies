
readme.txt

before you work with Fish or your Shnth, you should make sure your 'cuisine' is the newest version.  This means to upload a fresh synthesizer matrix into your shnth, and it should take between 1 and 2 minutes.  You don't need to have a patch open, but it will work with one open, too.  do this now:
click on Shnth menu. 
click on "Change cuisine"
in the file browser that opens, navigate to the "synth" directory.
select "wanilla.bin"
let it upload, and confirm that it does by watching flickering red lights on shnth.

thanks

when you start Fish, you will first see a window with:
- a menu
- the bouillabaisse bar (two yellow arrowheads with a white 'bb' in between)
- a blank grey screen with a salmon-colored egg in the upper left corner

there will also be a floating palette (calanque) with all the available fish listed on it. you can drag the calanque around to change its shape.

to get started, drag and release a fish from the calanque onto the egg. it is usually good to start with a DAC, Left or Right. then drag another fish onto the upper right end of the first fish so that a green haze appears there. then release the fish - the fish should now be inside the first fish and you should see its name and its required parameters in its guts. the guts will automatically be filled with random values. you can change these values by clicking on them and typing in a new number. at the bottom of the fish, below its guts is its handle, you can click here to select the fish for editing (its outer border will turn blue). if you want to edit the fish's guts just click inside the part that needs editing..it will turn blue.  you can replace any fish by dragging another fish onto the middle of its handle..the fish to be replaced will become grey and hazy.if you instead drag onto the left side of its handle you will see a blue haze on the left and the new fish will be added before the current fish. if instead you drag a fish onto the right side of a fish's handle, the blue haze will be on the right and the new fish will be added after the current fish. 

you can add/edit/replace guts of fish already in your bouillabaisse in the same manner. if you drag onto the middle of a piece of guts it will grow grey and hazy and you will replace it. if you drag to either side of the guts you will see a green haze (green for guts) and the the new guts will be added. if added to the left side, the value currently in that position will scoot to the right one place. if you add guts to the end of a fish they will automatically appear as a mul or add when appropriate. you can also add fish, guts and bubbles (returns) by using the Edit menu. the Edit menu also has the familiar cut/copy/paste/delete commands as well as Duplicate (makes a copy of selection) and Randuplicate (makes a copy of selection with randomized values). Undo undoes your previous actions in reverse order.

you can save and name your files using the classic File menu (or command-S). your file will be saved as a perfectly formatted shlisp text file. you can also open a shlisp text file in fish and have it displayed as graphics, provided it is coded correctly. you can name individual bouillabaisses/situations by double-clicking on its tab and entering a new name - these will show up as comments in the saved text file.

you can start a new bouillabaisse using the Bouillabaisse menu (or command-B).. a new bowl of bouillabaisse equates to a new situation in text shlisp. you can duplicate the current bowl to make subtle variations to it using Duplicate from the Bouillabaisse menu (shift-command-D). you can make a copy with all parameter values randomized using Randuplicate (shift-command-R). if you want to keep some parameters from being randomized you can freeze them by doubleclicking on the  parameter (or, if the whole fish, the fish's handle) - it will turn grey meaning it is now frozen at the current value. you can automatically make [i]n[/i] copies with random parameter values using Randuplicate... enter how many copies you want in the dialog and then click the red x to close the window, the bowls will be created automatically. mouse over the yellow arrowheads to sctoll forwards or backwards through them. you can drag bowls around to rearrange them, you can use shift-delete to delete ones you don't like; you can even drag a bowl from one open window to another. Randuplicate and Randuplicate... are especially useful with the opcodes Jump and Bend. 

you can then upload all bouillabaisses to your Shnth using the Shnth menu (or command-U). you can also just upload the currently selected bouillabaisse to your shnth using command-T. this is useful for auditioning; remember to upload any new bouillabaisses you create to your Shnth in order to hear them! New Cuisine is for uploading a new matrix to your Shnth, you won't need to do this very often.

Black and White mode is useful for printing the current bouillabaisse to use as a score, which can be accomplished from the File menu (or using command-P); the file will be saved as a .png 
