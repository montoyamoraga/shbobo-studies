

class JuliaTabs : public Component {
 protected:

 class JuliaSuzan : public Component {
  protected:
  class SuzanThread : public Thread {
   protected:
   float poz;
   Component * tobemoved;
   Component * inwhich;
   float speedup;
   bool left,right;
   public:
   SuzanThread(Component*tbm,Component*inw) : 
    tobemoved(tbm), inwhich(inw), Thread("SuzanThread") {
    left = right = false; poz = 0; speedup=0;
   }
   void setPoz(int plaza) {
    poz = 30-plaza;
    tobemoved->setTopLeftPosition(poz,0);
   }
   void run() {
    while (!threadShouldExit()) {
     if (left) 
      speedup+=0.1;
     else if (right) 
      speedup-=0.1; 
     poz += speedup;
     if (poz+tobemoved->getWidth() < inwhich->getWidth()-30)
      poz = inwhich->getWidth()-30-tobemoved->getWidth();
     if (poz > 30) poz = 30;
     tobemoved->setTopLeftPosition(poz,0);
     wait (20);
    }
   }
   void changeDir(bool l, bool r) {
    if ((l == left) && (r == right)) return;
    speedup = 0;
    left = l; right = r;
   }
  };
    
  Component*tobemoved;
  float poz;
  SuzanThread * sz;
  public:
  JuliaSuzan(Component*tbm):
   Component(), tobemoved(tbm) {
   sz = new SuzanThread(tbm,this);
   sz->startThread();
   addAndMakeVisible(tbm);
   tbm->setTopLeftPosition(30,0);
   tbm->addMouseListener(this,true);
  }
  void setPoz(int plaza)  {
   sz->setPoz(plaza);
   
  }
  void paintOverChildren (Graphics& g) {
   g.setColour(Colours::yellow);
   Path p;
   p.startNewSubPath (getWidth(), getHeight()/2);
   p.lineTo(getWidth()-30, getHeight());
   p.lineTo(getWidth()-30, 0);
   p.closeSubPath();
   g.fillPath (p);
   Path q;
   q.startNewSubPath (0, getHeight()/2);
   q.lineTo(30, getHeight());
   q.lineTo(30, 0);
   q.closeSubPath();
   g.fillPath (q);
  }
  void mouseMove (const MouseEvent& e) {
   MouseEvent ee = e.getEventRelativeTo (this);
   if (ee.getPosition().getX() < 30) {
     sz->changeDir(true,false);
   } else if (ee.getPosition().getX() > getWidth()-30) {
     sz->changeDir(false,true);
   } else sz->changeDir(false,false);
  }
  void mouseEnter (const MouseEvent& e) {
   mouseMove (e);
  }
  void mouseExit (const MouseEvent& e) {
   MouseEvent ee = e.getEventRelativeTo (this);
   if ( !contains ( ee.getPosition( ))) 
    sz->changeDir(false,false);
  }

  void mouseDrag (const MouseEvent& e) { mouseMove(e); }
 };

  class JuliaBar : public Component, 
   //public ChangeBroadcaster, 
   public DragAndDropContainer
    {
   protected:

   class SoupCrock : public ActionCel {
    protected:
    //friend class JuliaBar;
    GutsLabel*guts;
    JuliaBar* owner;
    Bouillabaisse*broth;
    Viewport * vp;
    public:
    enum gutscolours {tinto = 0x3488};
    SoupCrock (const String& name, Bouillabaisse*bro, JuliaBar* own) : 
    owner(own), ActionCel("SoupCrock") { //, broth(bro)
     setColour(haze, Colours::yellow);
     broth = bro;
     guts = new GutsLabel(name);
     addAndMakeVisible(guts);
     guts->setEditable(false,true);
     guts->addMouseListener(this,true);
     childBoundsChanged (nullptr);
     vp = new Viewport();
     vp->setViewedComponent(broth);
    }
    ~SoupCrock() { delete (guts); }
    void childBoundsChanged (Component* child) {
     setSize(guts->getWidth(),30);
     guts->setTopLeftPosition(1,(30-guts->getHeight())/2);
    }
    Bouillabaisse*getBroth() { 
     return broth; }
    Viewport * getView() { return vp; }
    void processString(const String & s) {
     guts->setText(s);
    }
    const String getText() const {

     return guts->getText();  
    } void setOwner( JuliaBar*o) {owner = o; }
    void paint (Graphics& g) {
     g.setColour (findColour(tinto));
     g.fillRoundedRectangle (0,0, getWidth(), getHeight(),20);
    }
    bool reszultOfMouseDownSelectMethod;
    void mouseDown(const MouseEvent &evnt) {
     static_cast<JuliaBar*>(getParentComponent())
       ->setCurrentCrock(getIndex());
     
    }
    int getIndex() const {
     return getParentComponent()->getIndexOfChildComponent(this);
    }
    void colourChanged () {repaint();}
    bool isInterestedInDragSource (const SourceDetails &sd) { 
     if (sd.sourceComponent->getName() == "SoupCrock") return true;
     return false; }
    void itemDropped (const SourceDetails &sd) { 
     ActionCel::itemDropped(sd);
     Component * f = sd.sourceComponent.get(); 
     SoupCrock * sc = static_cast<SoupCrock*>(f);
     Component * paro = f->getParentComponent();
     if (!paro) return;
     JuliaBar * jb = static_cast<JuliaBar*>(paro);
     jb->setCurrentCrock(sc->getIndex());
    }
   };

   JuliaTabs& owner;
   OwnedArray <SoupCrock> tabs;
   int currentCrockIndex;
   bool clearing;
   public:
   JuliaBar (JuliaTabs& owner_) : owner(owner_) {
    //addAndMakeVisible (sc); 
    // setCurrentCrock (0);
    //addCrock("bb", new Bouillabaisse());
    clearing = false;
   }
   ~JuliaBar() {
    
   }
   
   void clearCrocks() {
    
    while (getNumCrocks()) {
     clearing = true;
     removeChildComponent(0);//removeCrock(0);
     //printf("decrocking\n");
    }
    
   }
    
   void childBoundsChanged (Component* child) {
    int childro = getNumCrocks ();
    int wido = 0;
    int hido = 30;
    for (int i = 0; i < childro; i++) {
     Component* c = getCrock (i);
     c->setTopLeftPosition(wido,0);
     wido += c->getWidth();
    } setSize(wido,hido);
   }
   void childrenChanged () { 
    childBoundsChanged(this);
    //printf("JuliBarchildchang\n");
    
    currentCrockChanged();
    if (!getNumCrocks() ) {
     if (!clearing)
      addCrock("bb", new Bouillabaisse());
    }
    clearing = false;
   }
   void addCrock (const String& tabName, Bouillabaisse*bro) {
    SoupCrock*sc = new SoupCrock(tabName,bro,this);
    mastroUndoicus->beginNewTransaction();
    if (getNumCrocks())  {
     FudgeAction * scooty = new FudgeAction(sc,getCrock(getCurrentCrock())) ;
     mastroUndoicus->perform(scooty); setCurrentCrock (getCurrentCrock()+1);
    } else  { addAndMakeVisible (sc); 
     setCurrentCrock (0); }
   }
   void removeCrock (int tabIndex) {
    mastroUndoicus->beginNewTransaction();
    if (getNumCrocks())  {
     TakeAction * takey = new TakeAction(getCrock(getCurrentCrock()));
     mastroUndoicus->perform(takey);
    }
    
    
   }
   SoupCrock* getCrock(int i) {
    if (getNumCrocks()) 
     return static_cast<SoupCrock*>(getChildComponent(i));
    else return nullptr;
   }
   int getNumCrocks() const {
    return getNumChildComponents();
   }
   void setCurrentCrock (int newIndex) {
    currentCrockIndex = newIndex;
    currentCrockChanged();
   }
   Bouillabaisse * getBroth(int i) {
    if (getNumCrocks()) 
     return getCrock(i)->getBroth();
    else return nullptr;
   }
   Viewport * getView(int i) {
    if (getNumCrocks()) 
     return getCrock(i)->getView();
    else return nullptr;
   }
   String getCurrentCrockName() { 
    return getCrockName(getCurrentCrock());
   }
   int getCurrentCrock() {
    if (currentCrockIndex >= getNumCrocks())  
     currentCrockIndex = getNumCrocks() - 1;
     return currentCrockIndex; 
   }
   String getCrockName (int i) { 
    if (getNumCrocks()) 
     return getCrock(i)->getText();
    else return "";
   }
   void currentCrockChanged () {
    for (int i = 0; i < getNumCrocks(); i++) {
     if (i == getCurrentCrock())
      getCrock(i)->setColour(SoupCrock::tinto,Colours::white);
     else getCrock(i)->setColour(SoupCrock::tinto,Colours::grey);
    }
    owner.changeCallback ();
   }
   virtual void popupMenuClickOnTab (int tabIndex, const String& tabName) {}
   //void resized();
   //void lookAndFeelChanged();
   void paint (Graphics& g) {
    g.setColour (Colours::red);
    g.fillRoundedRectangle (0,0, getWidth(), getHeight(),20);
   }
  };
 
 enum ColourIds {
  
 backgroundColourId = 0x1005800, outlineColourId = 0x1005801};
 JuliaBar * bar;
 JuliaSuzan * sz;
 Viewport * panelComponent;
 public:
 JuliaTabs () : panelComponent(nullptr) {
  
  sz = new JuliaSuzan(bar = new JuliaBar (*this));
  bar->addCrock ("bb",new Bouillabaisse());
  //printf("tabs\n");
  addAndMakeVisible (sz); //panelComponent = nullptr;
   
 }
 ~JuliaTabs() {}
 void clearCrocks() {
  bar->clearCrocks();
 }
 void addCrock (const String& tabName,
                 Bouillabaisse* contentComponent) {
  
  bar->addCrock (tabName, contentComponent);
  resized();
 }
 void removeCrock (int i) {
  bar->removeCrock(i);
 }
 int getNumCrocks() const {
  return bar->getNumCrocks();
 }
 Bouillabaisse* getBroth (int i){
  return bar->getBroth (i);
 } 
 void setCurrentCrock(int i, bool sendChangeMessage = true) {
  bar->setCurrentCrock(i);
 }
 int getCurrentCrock() {
  return bar->getCurrentCrock();
 }
 String getCrockName(int it) {
  return bar->getCrockName(it);
 }
 String getCurrentCrockName() {
  
  return bar->getCurrentCrockName();
 }
 Bouillabaisse* getCurrentBroth() { 
  return bar->getBroth(getCurrentCrock()); 
 }

 void paint (Graphics& g) {
  //g.setColour (Colours::blue);
  //g.fillRoundedRectangle (0,0, getWidth(), getHeight(),20);
 }
 void resized() {
  juce::Rectangle<int> content(getLocalBounds());
  sz->setBounds(0,0,getWidth(),30);
  for (int i = getNumCrocks(); --i >= 0;)
   if (bar->getView(i) != nullptr) {
    bar->getView(i)->setBounds (0,30,getWidth(),getHeight()-30); }
 }
 virtual void currentCrockChanged (int i) {}
 void changeCallback () {
  if (panelComponent != nullptr) {
   panelComponent->setVisible (false);
   removeChildComponent (panelComponent);
   panelComponent = nullptr;
  }  
  if (getCurrentCrock() >= 0) {
   panelComponent = bar->getView(getCurrentCrock());
   //printf("cro\n");
   if (panelComponent != nullptr) {
    addChildComponent (panelComponent);
    panelComponent->setVisible (true);
    panelComponent->toFront (true);
   }
   repaint();
   currentCrockChanged (getCurrentCrock());
  }
  resized();
 }
};

