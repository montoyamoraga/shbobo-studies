#ifndef __SEAFOODHEADER__
#define __SEAFOODHEADER__

#include "../JuceLibraryCode/JuceHeader.h"



class Seafood : public ActionCel, public ChangeListener, public TooltipClient {
 protected:
 Colour hereyago;
 RibsLabel* sub;
 Component* withme;
 Skul * skl;
 bool frozen;

 public:
 enum gutscolours {rimma = 0x3256, liver};
 static SelectedItemSet<Seafood*> cowboySmall;
 Seafood(const String& nameo) : ActionCel(nameo), frozen(false) {
  sub = new RibsLabel(String(""));
  sub->addMouseListener(this,0);
  skl = nullptr;
  cowboySmall.addChangeListener(this);
 }
 Seafood(const Seafood& sg) : ActionCel(sg), frozen(false) {
  frozen = sg.frozen;
  sub = new RibsLabel(sg.sub->getText());
  sub->addMouseListener(this,0);
  skl = nullptr;
  cowboySmall.addChangeListener(this);
 }
 ~Seafood() {
  cowboySmall.removeChangeListener(this);
  delete(sub);
  delete(withme);
  cowboySmall.deselect (this);
 }
 String getTooltip() { if (skl) return skl->getTooltip(); 
  else return "";
 }
 static Seafood * copyGuts( Seafood* sg, bool rando);
 void liverColour(int numba) {
  uint8 hh = numba;
  uint8 green = (hh <= 128 ? hh : 256 - hh) + 126 + 1;
  setColour(liver, Colour::fromRGB((511-hh)>>1,green,(255+hh)>>1));
 }
 virtual int getNumba() { return 0; }
 void  changeListenerCallback (ChangeBroadcaster *source) {
  if (cowboySmall.isSelected(this)) setColour(rimma, Colours::blue);
  else setColour(rimma, Colours::black);
  repaint();
 }
 void childBoundsChanged (Component* child) {
  int maxwido;
   if (withme->getWidth() > sub->getWidth())
    maxwido = withme->getWidth();
   else {
    maxwido = sub->getWidth();
   }
   setSize(maxwido+2, 2+sub->getHeight()+withme->getHeight());
   withme->setTopLeftPosition(1,1);
   sub->setTopLeftPosition(1,1+withme->getHeight());
 }
 Skul* getSkull() { return skl; }
 void setSub(const String texto) {
  sub->setText(texto);
 }
 void paint(Graphics &g) {
  
  g.setColour (findColour(liver));
  if (LookAndFeel::getDefaultLookAndFeel().isColourSpecified (liver))
   g.setColour (LookAndFeel::getDefaultLookAndFeel().findColour(liver));
  g.fillRoundedRectangle (0,0, getWidth(), getHeight(),20);
 }
 void paintOverChildren (Graphics& g) {
  if (frozen) {
   g.setColour (Colours::whitesmoke.withAlpha ((float)0.5));
   g.fillRoundedRectangle (0,0, getWidth(), getHeight(),20);
  }  ActionCel::paintOverChildren (g);
 }
 virtual void chubber(Chubbalyzer * c) {}
 virtual void printar(FileOutputStream * f) {}

 void mouseDoubleClick (const MouseEvent& e) {
  if (frozen) frozen = false;
  else frozen = true;
  repaint();
 }
 bool reszultOfMouseDownSelectMethod;
 void mouseDown(const MouseEvent &evnt) {
  reszultOfMouseDownSelectMethod = 
   cowboySmall.addToSelectionOnMouseDown(this,
        evnt.mods);
 }
 void mouseUp(const MouseEvent &evnt) {
  cowboySmall.addToSelectionOnMouseUp(this,
   evnt.mods, dragon, reszultOfMouseDownSelectMethod);
 }
 bool isInterestedInDragSource (const SourceDetails &sd) { 
  if (sd.sourceComponent->getName() == "SoupCrock") return false; 
  return true; 
 }
};
SelectedItemSet<Seafood*> Seafood::cowboySmall;
SelectedItemSet<Seafood*> copyBuffa;

#endif

