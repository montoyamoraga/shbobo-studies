//#pragma once

static signed char gwonzulate[8];
static unsigned char mastroBarcode =0;

class Chub {
protected:
 signed char gwonz[8];
public:
 
 void chubOPEN();
 void chubRUN();
 virtual void chubCALL() {}
 virtual bool chubShouldEnd(){return false;}
 void chubSENDATE(unsigned char * rept);
 void chubSENDEND();
 void chubCLOZ();
};

#if defined(LINUSTORWALDS)
#include <libusb-1.0/libusb.h>
#include "chub_lin.h"
#elif defined(BILLGATES)
//extern "C" {
 #include <windows.h>
 #include <wchar.h>
 #include <setupapi.h>
//}
#include "chub_win.h"
#elif defined(STEVEJOBS)
#include <IOKit/hid/IOHIDLib.h>
#include "chub_mac.h"
#endif
