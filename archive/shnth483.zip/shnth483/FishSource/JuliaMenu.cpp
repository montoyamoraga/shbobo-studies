bool tooltipMode = false;
bool bwMode = false;
class JuliaMenu : 
 public MenuBarModel,
 public ApplicationCommandTarget {
 protected:
	 
 enum CommandIDs {
  newPhile = 0x2000,
  openPhile, savePhile, saveAsPhile, printBouillabaisse,
  undoEdit, redoEdit,
  cutEdit, copyEdit, pasteEdit, deleteEdit,
  dupEdit, dupEditRef, randupEdit,
  insertReturn, insertFish, insertGuts,
  bbaisseNew, bbaisseDup, bbaisseRandup,bbaisseRandupddd, bbaisseDel, 
	 bbaisseBW, tooltipTog, brax,
  upLoad, upLoadTab, upLoadMatrix, gwonzer, barcoder
 };
 public:
 ApplicationCommandManager* commandManager;
 JuliaMenu() {
  //bwMode = tooltipMode = false;
  commandManager = new ApplicationCommandManager();
  commandManager->registerAllCommandsForTarget(this);
  setApplicationCommandManagerToWatch(commandManager);
 }
 ~JuliaMenu() { delete (commandManager); }
 StringArray getMenuBarNames() {
  const char* const names[] = { "File", //"Edit", 
   "Edit", "Bouillabaisse", "View", "Shnth", nullptr };
  return StringArray (names);
 }
 PopupMenu getMenuForIndex (int menuIndex, const String&) {
  PopupMenu menu;
  if (menuIndex == 0) {
   menu.addCommandItem (commandManager, newPhile,String("New"));
   menu.addCommandItem (commandManager,openPhile,String("Open"));
   menu.addCommandItem (commandManager, savePhile,String("Save"));
   menu.addCommandItem (commandManager, saveAsPhile,String("Save as..."));
   menu.addCommandItem (commandManager, printBouillabaisse,String("Print Bouillabaisse")); 
  } else if (menuIndex == 1) {
   menu.addCommandItem (commandManager, undoEdit, String("Undo"));
   menu.addCommandItem (commandManager, redoEdit, String("Redo"));
   menu.addSeparator();
   menu.addCommandItem (commandManager, cutEdit, String("Cut"));
   menu.addCommandItem (commandManager, copyEdit, String("Copy"));
   menu.addCommandItem (commandManager, pasteEdit, String("Paste"));
   menu.addCommandItem (commandManager, dupEdit, String("Duplicate"));
   menu.addCommandItem (commandManager, randupEdit, String("Randuplicate"));
   menu.addCommandItem (commandManager, dupEditRef, String("Reference"));
   menu.addCommandItem (commandManager, deleteEdit, String("Delete"));
   menu.addSeparator();
   menu.addCommandItem (commandManager, insertReturn, String("Bubble"));
   menu.addCommandItem (commandManager, insertFish, String("Poisson"));
   menu.addCommandItem (commandManager, insertGuts, String("Guts"));
	  
  } else if (menuIndex == 2) {
   menu.addCommandItem (commandManager, bbaisseNew, String("New"));
   menu.addCommandItem (commandManager, bbaisseDup, String("Duplicate"));
   menu.addCommandItem (commandManager, bbaisseRandup, String("Randuplicate"));
   menu.addCommandItem (commandManager, bbaisseRandupddd, String("Randuplicate..."));
   menu.addCommandItem (commandManager, bbaisseDel, String("Delete"));
  } else if (menuIndex == 3) {
	  menu.addCommandItem (commandManager, bbaisseBW, String("Black and white"));
	  menu.addCommandItem (commandManager, tooltipTog, String("Tooltips")); 
	menu.addCommandItem (commandManager, brax, String("Square brackets out"));   
  } else if (menuIndex == 4) {
   menu.addCommandItem (commandManager, upLoadTab, String("Serve this"));
   menu.addCommandItem (commandManager, upLoad, String("Serve all"));
   menu.addCommandItem (commandManager, upLoadMatrix, String("Change cuisine"));
   menu.addCommandItem (commandManager, gwonzer, String("Gwonzer"));
   menu.addCommandItem (commandManager, barcoder, String("Barcoder"));
  }
  return menu;
 }
 void menuItemSelected (int menuItemID, int) {}
 ApplicationCommandTarget* getNextCommandTarget() { 
  return findFirstTargetParentComponent();
 }
 void getAllCommands (Array <CommandID>& commands) {
  const CommandID ids[] = { 
  newPhile,
  openPhile, savePhile, saveAsPhile, printBouillabaisse,
  undoEdit, redoEdit,
  cutEdit, copyEdit, pasteEdit, deleteEdit,
  dupEdit, dupEditRef, randupEdit,
  insertReturn, insertFish, insertGuts,
  bbaisseNew, bbaisseDup, bbaisseRandup, bbaisseRandupddd, bbaisseDel,
	  bbaisseBW,tooltipTog,brax,
  upLoad, upLoadTab, upLoadMatrix, gwonzer, barcoder
  };
  commands.addArray (ids, numElementsInArray (ids));
 }
 void getCommandInfo (CommandID commandID, ApplicationCommandInfo& result) {
  const String filesz ("File");
  const String edtit ("Edit");
  const String bbaiss ("Bouillabaisse");
	 const String vfiew ("View");
  const String devicz ("Device");
  switch (commandID) {
   case newPhile:
    result.setInfo ("New File", "Makes a new file", filesz, 0);
    result.addDefaultKeypress ('n', ModifierKeys::commandModifier);
    break;
   case openPhile:
    result.setInfo ("Open File", "Open a file", filesz, 0);
    result.addDefaultKeypress ('o', ModifierKeys::commandModifier);
    break;
   case savePhile:
    result.setInfo ("Save File", "Save this file", filesz, 0);
    result.addDefaultKeypress ('s', ModifierKeys::commandModifier);
    break;
   case saveAsPhile:
    result.setInfo ("Save as File", "Saves as another file", filesz, 0);
    result.addDefaultKeypress ('s', ModifierKeys::commandModifier| ModifierKeys::shiftModifier);
    break;
   case printBouillabaisse:
    result.setInfo ("Print Bouillabaisse", "Print the current bouillabaisse to PNG format", filesz, 0);
    result.addDefaultKeypress ('p', ModifierKeys::commandModifier);
    break;
   case upLoad:
    result.setInfo ("Serve all", "Send all bouillabaisse to the SHNTH", devicz, 0);
    result.addDefaultKeypress ('u', ModifierKeys::commandModifier);
    break;
   case upLoadTab:
    result.setInfo ("Serve this", "Send just this bouillabaisse to the SHNTH", devicz, 0);
    result.addDefaultKeypress ('t', ModifierKeys::commandModifier);
    break;
   case upLoadMatrix:
    result.setInfo ("Change cuisine", "Upload a new DSP matrix to device", devicz, 0);
    result.addDefaultKeypress ('u', ModifierKeys::commandModifier | ModifierKeys::shiftModifier);
    break;
   case gwonzer:
    result.setInfo ("Gwonzer", "Look at the data from the device", devicz, 0);
    result.addDefaultKeypress ('g', ModifierKeys::commandModifier | ModifierKeys::shiftModifier);
    break;
	  case barcoder:
		  result.setInfo ("Barcoder", "Set the bar orientation", devicz, 0);
		  result.addDefaultKeypress ('b', ModifierKeys::commandModifier | ModifierKeys::shiftModifier);
		  break;
   case undoEdit:
    result.setInfo ("Undo", "Undo changes on the current bouillabaisse", edtit, 0);
    result.addDefaultKeypress ('z', ModifierKeys::commandModifier );
    break;
   case redoEdit:
    result.setInfo ("Redo", "Redo changes on the current bouillabaisse", edtit, 0);
    result.addDefaultKeypress ('z', ModifierKeys::commandModifier | ModifierKeys::shiftModifier);
    break;
   case cutEdit:
    result.setInfo ("Cut", "Cut any selected seafood", edtit, 0);
    result.addDefaultKeypress ('x', ModifierKeys::commandModifier );
    break;
   case copyEdit:
    result.setInfo ("Copy", "Copy any selected seafood", edtit, 0);
    result.addDefaultKeypress ('c', ModifierKeys::commandModifier );
    break;
   case pasteEdit:
    result.setInfo ("Paste", "Paste after the last selected seafood", edtit, 0);
    result.addDefaultKeypress ('v', ModifierKeys::commandModifier );
    break;
   case dupEdit:
    result.setInfo ("Duplicate", "Duplicate any selected seafood", edtit, 0);
    result.addDefaultKeypress ('d', ModifierKeys::commandModifier );
    break;
   case dupEditRef:
    result.setInfo ("Reference", "Duplicate any poisson as a reference", edtit, 0);
    result.addDefaultKeypress ('f', ModifierKeys::commandModifier );
    break;
   case randupEdit:
    result.setInfo ("Randuplicate", "Randuplicate any selected seafood", edtit, 0);
    result.addDefaultKeypress ('r', ModifierKeys::commandModifier );
    break;
   case deleteEdit:
    result.setInfo ("Delete", "Delete any selected seafood", edtit, 0);
    result.addDefaultKeypress (KeyPress::backspaceKey, 0 );
    break;
/////////////////////////
   case insertReturn:
    result.setInfo ("Bubble", "Put a bubble after the last selected seafood", edtit, 0);
    result.addDefaultKeypress (KeyPress::returnKey, 0);
    break;
   case insertFish:
    result.setInfo ("Poisson", "Put a poisson after the last selected seafood", edtit, 0);
    result.addDefaultKeypress ('p',0);
    break;
   case insertGuts:
    result.setInfo ("Guts", "Put a guts after the last selected seafood", edtit, 0);
    result.addDefaultKeypress ('g',0);
    break;

   case bbaisseNew:
    result.setInfo ("New Bouillabaisse", "Make a new bouillabaisse", bbaiss, 0);
    result.addDefaultKeypress ('b', ModifierKeys::commandModifier );
    break;
   case bbaisseDup:
    result.setInfo ("Duplicate Bouillabaisse", "Duplicate the current bouillabaisse", bbaiss, 0);
    result.addDefaultKeypress ('d', ModifierKeys::commandModifier | ModifierKeys::shiftModifier);
    break;
   case bbaisseRandup:
    result.setInfo ("Randuplicate Bouillabaisse", "Randuplicate the current bouillabaisse", bbaiss, 0);
    result.addDefaultKeypress ('r', ModifierKeys::commandModifier | ModifierKeys::shiftModifier);
    break;
   case bbaisseRandupddd:
    result.setInfo ("Randuplicate Bouillabaisse...", "Randuplicate the current bouillabaisse n times", bbaiss, 0);
    break;
   case bbaisseDel:
    result.setInfo ("Delete Bouillabaisse", "Delete the current bouillabaisse", bbaiss, 0);
    result.addDefaultKeypress (KeyPress::backspaceKey, ModifierKeys::shiftModifier );
    break;
  case tooltipTog:
	result.setInfo ("Toggle tooltips", "Turn the tooltips on and off", vfiew, 0);
    result.setTicked (tooltipMode);
    break;
   case bbaisseBW:
    result.setInfo ("Black and white Bouillabaisse", "View as black and white", vfiew, 0);
    result.setTicked (bwMode);
    //result.addDefaultKeypress (KeyPress::backspaceKey, ModifierKeys::shiftModifier );
    break;
   case brax:
    result.setInfo ("Square brax", "When saving, use square brackets", vfiew, 0);
    result.setTicked (writeSquareBrax);
    //result.addDefaultKeypress (KeyPress::backspaceKey, ModifierKeys::shiftModifier );
    break;
   default:
    break;
  };
 }

 bool perform (const InvocationInfo& info){
  char * bufstar ;
 switch (info.commandID) {
  case newPhile:
   newFile ();
   break;
  case openPhile:
   chooseFileToOpen ();
   break;
  case savePhile:
   saveFileFromEditor ();
   break;
  case saveAsPhile:
   chooseFileToSave () ;
   break;
  case printBouillabaisse:
   printoBouillo () ;
   break;

  case upLoad:
   chubberdubber();
   break;
  case upLoadTab:
   chubberdubbertab();
   break;
  case upLoadMatrix:
   uploadBinar();
   break;
  case gwonzer:
   gwonzero();
   break;
  case undoEdit:
   undoEdito();
   break;
  case redoEdit:
   redoEdito();
   break;
  case cutEdit:
   cutEdito();
   break;
  case copyEdit:
   copyEdito();
   break;
  case pasteEdit:
   pasteEdito();
   break;
  case dupEdit:
   dupEdito();
   break;
  case dupEditRef:
   dupEditoRef();
   break;
  case randupEdit:
   randupEdito();
   break;		 
  case deleteEdit:
   deleteEdito();
   break;

  case insertReturn:
   inserto(new Bubble());
   break;
  case insertFish:
   inserto(new Poisson());
   break;
  case insertGuts:
   inserto(new Fishgut());
   break;		 

  case bbaisseNew:
   bouillabaisseNew();
   break;
  case bbaisseDup:
   bouillabaisseDup();
   break;
  case bbaisseRandup:
   bouillabaisseRandup();
   break;
  case bbaisseRandupddd:
   bouillabaisseRandupDotDotDot();
   break;
  case bbaisseDel:
   bouillabaisseDel();
   break;
  case bbaisseBW:
   bouillabaisseBW();
   break;
	 case tooltipTog:
		 tooltipToggle();
		 break;
	 case barcoder:
		 barcodero();
		 break;
  case brax:
   if (writeSquareBrax) writeSquareBrax = false; 
   else writeSquareBrax = true; 
  break;
  default:
   return false;
 };
 return true;
}
 virtual void undoEdito() {}
 virtual void redoEdito() {}
 virtual void chubberdubber() {}
 virtual void chubberdubbertab() {}
 virtual void newFile() {}
 virtual void uploadBinar() {}
 virtual void gwonzero() {}
 virtual void cutEdito() {}
 virtual void copyEdito() {}
 virtual void pasteEdito() {}
 virtual void dupEdito() {}
 virtual void dupEditoRef() {}
 virtual void randupEdito() {}
 virtual void deleteEdito() {}
	 virtual void tooltipToggle() {}
 virtual void barcodero() {}
 virtual void inserto(Seafood*sf) {}

 virtual void openFileInEditor () {}
 virtual void chooseFileToOpen () {}
 virtual void saveFileFromEditor () {}
 virtual void chooseFileToSave () {}
 virtual void printoBouillo () {}

 virtual void bouillabaisseNew(){}
 virtual void bouillabaisseDup(){}
 virtual void bouillabaisseRandup(){}
 virtual void bouillabaisseRandupDotDotDot(){}
 virtual void bouillabaisseDel(){}
 virtual void bouillabaisseBW(){}
};
