
to run shlisp, you may need to sudo, or may not.
In a console, change directory into this folder,
and type one of the following three commands:
linux: ./shlisp
macintosh: ./shlisp.app
windows: .\shlisp.exe
without any arguments it will dump the HID data received from any SHNTH
./shlisp examp/vancouver.txt 
with the option -h, it spits out a list of the possible opcodes.
with the option -z, it spits out a list of the possible opcodes in Chinese
with the option -b, followed immediately by a number, it uses this number as the "barcode", eg -b255 inverts all bars.
after these options:
with one argument, it parses the phile as shlisp source, then transmits it to SHNTH.
with another argument, preferably ../wanilla.bin, it will update your synthesis matrix (1-4 minutes)

note about barcodes:
 you used to have to put a number at the beginning of your text, which was used by the shlisp interpreter as a barcode, to set the orientation of the bars.  because this makes a question mark pop up in one's head immediately upon reading a text, this feature is deprecated.  now you use the -b option if you want to set a barcode, otherwise it will be zero by default.  You can even leave the random number at the beginning of your text...  Expect this note to wither away as shlisp code is standardized WITHOUT barcode at beginning, as is intuitively natural.  

usb on linux does not connect to device unless you have permission.
you needs to use terminal to go to fish directory and run "sudo fish"
or, you can give permission for shnth by putting a file named "shnth.rules" inside the 
/etc/udev/rules.d/ directory.
the shnth.rules file should contain the following text:
SUBSYSTEM=="usb", ATTR{idVendor}=="6666", ATTR{idProduct}=="6666", MODE="0666"

