
class TakeAction : 
 public UndoableAction {
 protected:
 Component* who;
 Component* where;
 int which;
 public:
 TakeAction(Component*w) {
  who = w;
 }
 bool perform() {
  where = who->getParentComponent();
  if (!where) return false;
  which = where->getIndexOfChildComponent(who);
  where->removeChildComponent(who);
  return true;
 }
 bool undo() {
  if (!where) return false;
  where->addAndMakeVisible(who,which);
  return true;
 }
}; 

class PutinAction : 
 public UndoableAction {
 protected:
 Component* who;
 Component* whom;
 public:
 PutinAction(Component*o,Component*m) : 
  UndoableAction() {
  who=o;
  whom=m;
 } 
 ~PutinAction() {}
 bool perform() {
  if (!whom) return false;
  whom->addAndMakeVisible(who);
  return true;
 }
 bool undo() {
  if (!whom) return false;
  whom->removeChildComponent(who);
  return true;
 }
};

class ScootAction : 
 public UndoableAction {
 protected:
 Component* who;
 Component* whom;
 Component* where;
 public:
 ScootAction(Component*o,Component*m) : 
  UndoableAction() {
  who=o;
  whom=m;
 } 
 ~ScootAction() {}
 bool perform() {
  //printf("scooty\n");
  where = whom->getParentComponent();
  if (!where) return false;
  where->addAndMakeVisible(who);
  who->toBehind(whom);
  return true;
 }
 bool undo() {
  if (!where) return false;
  where->removeChildComponent(who);
  return true;
 }
};
 
class FudgeAction : 
 public UndoableAction {
 protected:
 Component* who;
 Component* whom;
 Component* where;
 public:
 FudgeAction(Component*o,Component*m) : 
  UndoableAction() {
  who=o;
  whom=m;
 } 
 ~FudgeAction() {}
 bool perform() {
  where = whom->getParentComponent();
  if (!where) return false;
  int indo = where->getIndexOfChildComponent(whom);
  where->addAndMakeVisible(who,indo+1);
  return true;
 }
 bool undo() {
  if (!where) return false;
  where->removeChildComponent(who);
  return true;
 }
};

class ActionCel : public Component , public DragAndDropTarget {
 protected:
  bool fudged, scootd;
 public:
 enum hazing {haze = 0x3356};
 ActionCel(const String& nameo) : Component(nameo) { fudged = scootd = false;}
 ActionCel(const ActionCel& sg) : Component(sg.getName()) { fudged = scootd = false;}
 ~ActionCel() {}
 void paintOverChildren (Graphics& g) {
  if (scootd) {
   g.setColour (findColour(haze).withAlpha((float)0.5));
   g.fillRoundedRectangle (0,0, getWidth()/3, getHeight(),20);
  } else if (fudged) {
   g.setColour (findColour(haze).withAlpha((float)0.5));
   g.fillRoundedRectangle (getWidth()*2/3,0, getWidth()/3, getHeight(),20);
  }
 }
 bool dragon;
 void mouseDrag(const MouseEvent &evnt) {
  dragon = true;
  DragAndDropContainer* dragC = 
  DragAndDropContainer::findParentDragContainerFor(this);
  if (!dragC->isDragAndDropActive()) 
    dragC->startDragging(var(getName()) ,this,Image::null, true );
 
 }
 void itemDropped (const SourceDetails &sd) { 
  itemDragExit (sd);
  Component * paro = this->getParentComponent();
  if (!paro) return;
  Component * f = sd.sourceComponent.get(); 
  if  (f == this || f->isParentOf(this)) return; 
  //UndoManager * b = findParentComponentOfClass<UndoManager>();
  //if (!b) return;
  mastroUndoicus->beginNewTransaction();
  TakeAction*takey=nullptr;
  /*if (f->getName() == "Skul") {
   Skul * rw = static_cast<Skul*> (f);
   f = rw->getFlesh(); 
  } else */ takey = new TakeAction(f);
  int xer = sd.localPosition.x;
  if (xer < getWidth()/3)  { 
   ScootAction*scooty = new ScootAction(f,this);
   if (takey) mastroUndoicus->perform(takey);
   mastroUndoicus->perform(scooty);
  } else if (xer > getWidth()*2/3)  { 
   FudgeAction*fudgey = new FudgeAction(f,this);
   if (takey) mastroUndoicus->perform(takey);
   mastroUndoicus->perform(fudgey);
  } else  { 
   ScootAction*scooty = new ScootAction(f,this);
   if (takey) mastroUndoicus->perform(takey);
   mastroUndoicus->perform(scooty);
   mastroUndoicus->perform(new TakeAction(this));
  }
 }

 bool isInterestedInDragSource (const SourceDetails &sd) { return false;}
 void itemDragEnter (const SourceDetails &sd) {} 
 void itemDragMove (const SourceDetails &sd) { 
  int xer = sd.localPosition.x;
  if (xer > getWidth()*2/3) {
   setAlpha (1);
   fudged = true; //setColour(fudgeHaze,Colours::blue.withAlpha((float)0.5));
  } else if (xer < getWidth()/3) {
   setAlpha (1); 
   scootd = true; //setColour(scootHaze,Colours::blue.withAlpha((float)0.5));
  } else {
   setAlpha (0.1); 
   fudged = scootd = false;//removeColour (scootHaze); 
   //removeColour (fudgeHaze); 
  } repaint();
 } 
 void itemDragExit (const SourceDetails &sd) {
  setAlpha (1);  fudged = scootd = false;  repaint();
  //removeColour (scootHaze); 
  //removeColour (fudgeHaze); 
 }
 virtual void processString(const String & s) {}
};

class StringAction : 
 public UndoableAction {
 protected:
 ActionCel* who;
 String sew;
 String old;
 public:
 StringAction(Component*w, String ol, String  ne) :
  sew(ne), old(ol) {
  who = dynamic_cast<ActionCel*>(w);
 }
 bool perform() {
  if (!who) return false;
  
  who->processString(sew);
  //printf("stringaction%s\n",old.toUTF8().getAddress());
  return true;
 }
 bool undo() {
  if (!who) return false;
  //printf("stringaction\n");
  who->processString(old);
  return true;
 }
}; 

class GutsLabel : public SizeLabel {
 protected:
  String lastext;
  void editorShown (TextEditor* editorComponent) {
   lastext = getText();
  }
  void editorAboutToBeHidden(TextEditor * t) {
   setGoodSize();
   Component * paro = this->getParentComponent();
   if (!paro) return; 
   //UndoManager * b = findParentComponentOfClass<UndoManager>();
   //if (!b) return;
   if (lastext==getText()) return;
   mastroUndoicus->beginNewTransaction();
   StringAction*stringy=new StringAction(paro,lastext,getText());
   mastroUndoicus->perform(stringy);
  }
 public:
  GutsLabel(const String &texto) : SizeLabel(texto) { 
   setEditable(true);
   setGoodSize();
  }
};

