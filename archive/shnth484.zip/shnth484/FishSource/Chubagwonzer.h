

class Chubagwonzer : public Chub, public Thread, public Component  {
 private:
  Label gwonzers[8];
  
 public:
	static DocumentWindow * dw;
 Chubagwonzer(): Thread("GwonzerThread") {
  setSize(400,100);
  for (int i = 0; i < 8; i++) 
   addAndMakeVisible(&gwonzers[i]);
  //startThread();
  for (int i = 0; i < 8; i++) {
   gwonzers[i].setText("gwnz",dontSendNotification);
	  gwonzers[i].setColour(Label::textColourId,Colours::green);
  }
#if defined(STEVEJOBS) 
  startThread();
#endif
 }
	~Chubagwonzer(){ stopThread(20); chubCLOZ();}
 bool chubShouldEnd() { return threadShouldExit(); }
 void run() { 
  chubOPEN();
  chubRUN(); printf("stopt\n");
 } 
 void resized() {
  for (int i = 0; i < 8; i++) {
   gwonzers[i].setBounds(getWidth()*i/8,0,200,getHeight());
   gwonzers[i].setFont(gwonzers[i].getFont().withHeight((getHeight()+getWidth())/16));
  }
 }
 void chubCALL() {
  for (int i = 0; i < 8; i++) {
   int gonz = gwonzulate[i];
   gwonzers[i].setText(String(gonz),dontSendNotification);
  }
 }
	static void showGwonz() {
  //DialogWindow::LaunchOptions launchOptions;
  //Chubagwonzer * chb = new Chubagwonzer();
	 //if (dw) return;
	 
		Chubagwonzer  chb;// = new Chubagwonzer();
	 //dw = new DocumentWindow("Spit Gwonz", Colours::black,7,true);
	 //dw->setVisible(true);
	 //dw->setContentOwned(chb,true);
   DialogWindow::showModalDialog ("Spit Gwonz", &chb,
                            nullptr, Colours::black, true, true, true);
  //chb.stopThread(20);
  //chb.chubCLOZ();
  //delete(chb);
  /*launchOptions.dialogTitle = ("Spit Gwonz");
  launchOptions.escapeKeyTriggersCloseButton = true;
  launchOptions.resizable = true;
  launchOptions.useNativeTitleBar = false;
  launchOptions.useBottomRightCornerResizer = true;
  launchOptions.componentToCentreAround = nullptr;
  launchOptions.content.setOwned(new Chubagwonzer());
  launchOptions.content->setSize(640, 480);
  //launchOptions.launchAsync();
  //launchOptions.create();
  if (!dag) dag = launchOptions.launchAsync();*/
	}
};

class GwonzerWindow : public DocumentWindow {
 private: Chubagwonzer chb;
public: 
	GwonzerWindow() : DocumentWindow("SpitGwonz", Colours::black,7,true) {
		setVisible(true);
		setResizable(true,true);
		setContentOwned(&chb,true);
	}
	~GwonzerWindow(){}
	void closeButtonPressed 	( 		); 
};
		
		
		
 GwonzerWindow * gw = nullptr;
void GwonzerWindow::closeButtonPressed () {
	delete(this); gw = nullptr;
}

 /* void Chubagwonzer::showGwonz() {
	if (gw) return;
	else gw = new GwonzerWindow();
} */
