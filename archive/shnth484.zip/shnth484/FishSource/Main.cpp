//#include "chub.h"
#include <stdio.h>
#include <string.h>
#include "chub.h"
#include <stdio.h>
#include <string.h>

#include "../JuceLibraryCode/JuceHeader.h"

#include "Chubbalyzer.h"

UndoManager * mastroUndoicus;
TooltipWindow * ttw;
bool writeSquareBrax = false;
#include "Julia.cpp"


class ShboboFish : public JUCEApplication {
public:
 
 ShboboFish(){}
 ~ShboboFish(){}
 void initialise (const String& commandLine) {
  writeSquareBrax = false;
  mastroUndoicus = new UndoManager();
  lokfeel.setColour(Seafood::liver,Colours::white);
lokfeel.setColour(Intestine::liver,Colours::grey);
  GoneFishing * gf = new GoneFishing();
  JuliaWindow::juliaz.add(new JuliaWindow());
 }
 void shutdown() {
  //jj = 0; //tt = 0;
 }
 const String getApplicationName() {
  return "Fish by Shbobo";
 }
 const String getApplicationVersion() {
  return ProjectInfo::versionString;
 }
 bool moreThanOneInstanceAllowed() {
  return false;
 }
 void anotherInstanceStarted (const String& commandLine) {JuliaWindow::juliaz.add(new JuliaWindow());}
private:
};

START_JUCE_APPLICATION (ShboboFish)

