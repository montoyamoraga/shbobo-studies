#include "../JuceLibraryCode/JuceHeader.h"
#include "ActionCel.h"
#include "LabelSkull.cpp"
#include "Seafood.h"

class Fishgut : public Seafood {
 protected:
 int spoon;
 public:  
 Fishgut() : Seafood("Fishgut") {
  spoon = rand() % 255 - 128;
  withme = new GutsLabel(String(spoon));
  withme->addMouseListener(this,0);
  addAndMakeVisible (withme);
  addAndMakeVisible (sub);
  liverColour(getNumba());
  setColour(haze, Colours::green);
  childBoundsChanged (this);
 }
 Fishgut(String & ss) : Seafood("Fishgut") {
   withme = new GutsLabel("");
   withme->addMouseListener(this,0);
   addAndMakeVisible (withme);
   addAndMakeVisible (sub);
   processString(ss);
   liverColour(getNumba());
   childBoundsChanged (this);
   setColour(haze, Colours::green);
  }
  Fishgut(Fishgut & sg) : Seafood(sg) {
   withme = new GutsLabel("");
   withme->addMouseListener(this,0);
   addAndMakeVisible (withme);
   addAndMakeVisible (sub);
   spoon = sg.spoon;
   skl = sg.skl;
   updateLabel();
   liverColour(getNumba());
   setColour(haze, Colours::green);
   childBoundsChanged (this);
  }
  Fishgut(Skul*sk, int spo) : 
   Seafood("Fishgut"), spoon(spo) { 
   withme = new GutsLabel("");
   withme->addMouseListener(this,0);
   addAndMakeVisible (withme);
   addAndMakeVisible (sub);
   skl = sk;
   skl->processSpoon(spoon);
   updateLabel();
   liverColour(getNumba());
   setColour(haze, Colours::green);
   childBoundsChanged (this);
  } 
 int getNumba() { 
  if (skl)
   return skl->getNum() | spoon;
  else
   return spoon; 
 }
 ~Fishgut() {}
 void chubber(Chubbalyzer * c) {
  if (skl) c->insituate(getNumba());
  else {
   if ((unsigned char)spoon == 0) {
    c->insituate(255);
    c->insituate(0);
   } else if ((unsigned char)spoon == 255) {
    c->insituate(255);
    c->insituate(242);
    c->insituate(0);
   } else c->insituate(spoon);
  }
 }
 void printar(FileOutputStream * f) {
  if (skl) {
   if (writeSquareBrax) 
    f->writeText("[" + skl->getName(spoon)+"] ",false,false);
   else f->writeText(skl->getName(spoon)+" ",false,false);
  }
  else f->writeText(String(spoon) + " ",false,false);
 }
 void updateLabel() {
  if (skl) { 
   skl->processSpoon(spoon);
   static_cast<SizeLabel*>(withme)->setText(skl->getName(spoon));
  } else { 
   static_cast<SizeLabel*>(withme)->setText(String(spoon));
  }
 }
 void processString (const String&ss) {
  String skulname = ss.substring(0,ss.length()-1);
  String spooner = ss.substring(ss.length()-1);
  if (standardo->getSkul(skulname)) {
   skl = standardo->getSkul(skulname);
   spoon = *(spooner.toUTF8().getAddress())-'a';
  } else if (standardo->getSkul(ss)) {
   skl = standardo->getSkul(ss);
   spoon = 0;
  } else  {
   spoon = ss.getIntValue();
   skl = nullptr;
  }
  updateLabel();
  liverColour(getNumba ());
  if (getParentComponent()) getParentComponent()->childrenChanged(); 
 }
 void colourChanged () {
  withme->setColour(Label::textColourId, findColour(rimma));
  sub->setColour(Label::textColourId, findColour(rimma));
  repaint();
 }
};

class LassFinder : public LassoSource<Seafood*> {
protected:
 Component * mastro;
public:
 LassFinder(Component * c) : mastro(c) {
 }
 void  findLassoItemsInArea (Array<Seafood*> &itemsFound, const juce::Rectangle< int > &area)
  {
  int childro = mastro->getNumChildComponents ();
  for (int i = 0; i < childro; i++) {
   Seafood* c = static_cast<Seafood*>(mastro->getChildComponent(i));
   if (c->getBounds().intersects(area) && (c->getName() != "Lasso")) {
    //if (!Seafood::cowboySmall.isSelected(c))
    itemsFound.add(c); }
  }
 }
 SelectedItemSet<Seafood*> & getLassoSelection (){
  return Seafood::cowboySmall;
 }
};
static LassoComponent<Seafood*>* lasso;

class Intestine : public Component , public DragAndDropTarget {
 protected:
 Colour hereyago;
 LassFinder* lasser;
  Seafood * hedskul;
 int cumulopasty;
 
 public:
 enum gutscolours {rimma = 0x3456, liver};
 static Fishgut dummy;
 Intestine() : Component("Intestine") {
  liverColour(cumulopasty=0);
  hedskul = nullptr;
  lasser = new LassFinder(this);
  childBoundsChanged(this);
  lasso = 0;
 } //follows is for reference dupe
 Intestine(Intestine& in) : Component("Intestine") {
  hedskul = in.hedskul;
  cumulopasty = in.cumulopasty;
  liverColour(cumulopasty);
  lasso = 0;
  lasser = new LassFinder(this);
  //int childro = in.getNumChildComponents ();
  if (hedskul) {
   //Component* c = in.getChildComponent (0);
   //Seafood * g = static_cast<Seafood*>(c);
   Seafood * ng = Seafood::copyGuts(hedskul, false);
   if (ng!=nullptr)
    addAndMakeVisible(ng);
  } 
  childBoundsChanged(this);
 }

 Intestine(Intestine& in, bool rando) : Component("Intestine") {
  hedskul = in.hedskul;
  cumulopasty = in.cumulopasty;
  liverColour(cumulopasty);
  lasso = 0;
  lasser = new LassFinder(this);
  int childro = in.getNumChildComponents ();
  for (int i = 0; i < childro; i++) {
   Component* c = in.getChildComponent (i);
   Seafood * g = static_cast<Seafood*>(c);
   Seafood * ng = Seafood::copyGuts(g, rando);
   if (ng!=nullptr)
    addAndMakeVisible(ng);
  } 
  childBoundsChanged(this);
 }
 ~Intestine() {
  delete(lasser);
  int childro = getNumChildComponents ();
  while (getNumChildComponents ()) {
   Component* c = getChildComponent (0);
   Seafood * g = static_cast<Seafood*>(c);
   removeChildComponent(g);
   delete(g);
  }
 }
 int getCumulopasty() {return cumulopasty;}
 void paint(Graphics &g) {
    g.setColour (findColour(liver));
  if (LookAndFeel::getDefaultLookAndFeel().isColourSpecified (liver))
   g.setColour (LookAndFeel::getDefaultLookAndFeel().findColour(liver));
  //g.setColour (findColour(liver));
  g.fillRoundedRectangle (0,0, getWidth(), getHeight(),20);
 }
 void mouseDown(const MouseEvent &evnt) { 
  Seafood::cowboySmall.deselectAll();
  lasso = new LassoComponent<Seafood*>();
  lasso->setName("Lasso");
  addAndMakeVisible(lasso);
  lasso->beginLasso (evnt, lasser);
 }
 void mouseDrag(const MouseEvent &evnt) {
  lasso->dragLasso (evnt);
 }
 void mouseUp(const MouseEvent &evnt) {
  lasso->endLasso();
  removeChildComponent(lasso);
  delete lasso;
  lasso = 0;
 }
  Seafood * getHedskul() { return hedskul; }
  void setSubs(Skul * skl) {
   //hedskul = skl;
   int childro = getNumChildComponents ();
   int t = 0;
   //if (!skl) return;
   for (int i = 0; i < childro; i++) {
    Component* c = getChildComponent (i);
    if (c->getName() == "Lasso") return;
    Seafood * g = static_cast<Seafood*>(c);
    if (skl) {
     //skl->ticker();
     if (g->getName() != "Bubble") {
      g->setSub(skl->getRib(t++));
 //     skl->ticker();
     } 
    } else g->setSub("");
   }
  }
 void chubberdubber(Chubbalyzer * chb) {
  int childro = getNumChildComponents ();
  for (int i = 0; i < childro; i++) {
   Component* c = getChildComponent (i);
   Seafood * g = static_cast<Seafood*>(c);
   g->chubber(chb);
  }
 } 
 void printartintar(FileOutputStream * f) {
  int childro = getNumChildComponents ();
  for (int i = 0; i < childro; i++) {
   Component* c = getChildComponent (i);
   Seafood * g = static_cast<Seafood*>(c);
   g->printar(f);
  }
 }
 void childBoundsChanged (Component* child) {
  int childro = getNumChildComponents ();
  int wido = 30;//dummy.getWidth();
  int hido = 0;
  int widocurxo = 0;
  int hidocurxo = 30;//dummy.getHeight();
  bool skulset = false;
  for (int i = 0; i < childro; i++) {
   Component* c = getChildComponent (i);
   if (c->getName() == "Lasso") return;
   c->setTopLeftPosition(widocurxo,hido);
   widocurxo += c->getWidth();
   if (c->getHeight() > hidocurxo) hidocurxo = c->getHeight();
   if (c->getName() == "Bubble") {
    hido += hidocurxo;
    hidocurxo = 0;
    if (widocurxo > wido) wido = widocurxo;
    widocurxo = 0;
   } else if (!skulset) {
    Seafood * g = static_cast<Seafood*>(c);
    setSubs(g->getSkull()); skulset = true;
   }
  } if (widocurxo > wido) wido = widocurxo; hido += hidocurxo;
  setSize(wido,hido);
 }
 void liverColour(int numba) {
  uint8 hh = numba;
  uint8 green = (hh <= 128 ? hh : 256 - hh) + 126 + 1;
  setColour(liver, Colour::fromRGB((511-hh)>>1,green,(255+hh)>>1));
 }
 void childrenChanged () { 
  cumulopasty = 0;
  childBoundsChanged(this);
  int childro = getNumChildComponents ();
  bool skulset = false;
  for (int i = 0; i < childro; i++) {
   Component* c = getChildComponent (i);
   if (c->getName() == "Lasso") return;
   cumulopasty += static_cast<Seafood*>(c)->getNumba();
   if (c->getName() == "Bubble") {} 
   else if (!skulset) {
    
    Seafood * g = static_cast<Seafood*>(c);
    hedskul = g;
    setSubs(g->getSkull()); skulset = true;
   }
  } liverColour(cumulopasty); repaint();
  if (getParentComponent()) getParentComponent()->childrenChanged(); 
 }
 bool isInterestedInDragSource (const SourceDetails &sd) { 
  if (sd.sourceComponent->getName() == "SoupCrock") return false;
  return true; }
 void itemDragEnter (const SourceDetails &sd) {} 
 void itemDragMove (const SourceDetails &sd) { }
 void itemDragExit (const SourceDetails &sd) {}
 void itemDropped (const SourceDetails &sd) { 
  Component * f = sd.sourceComponent.get();
  if  (f == this || f->isParentOf(this)) return; 
  mastroUndoicus->beginNewTransaction();
  mastroUndoicus->perform(new PutinAction(f,this));
 }
};
//String dummystring ("255");
//Fishgut Intestine::dummy;

class Bubble : public Seafood {
 public:
 Bubble() : Seafood("Bubble") {
  inizialize(""); 
 }
 Bubble(Bubble& sg) : Seafood(sg) {
  inizialize (static_cast<GutsLabel*>(sg.withme)->getText());
 } 
 Bubble(const String & commento) : Seafood("Bubble") {
  if (commento.isEmpty()) inizialize("");
  else inizialize(commento.substring(1).trimCharactersAtEnd("\n\r"));
 }
 void inizialize (const String & commento) {
  withme = new GutsLabel(commento);
  withme->addMouseListener(this,0);
  addAndMakeVisible (withme);
  addAndMakeVisible (sub);
  childBoundsChanged (this);
 }
 void paint(Graphics &g) {
  g.setColour (findColour(rimma).withMultipliedAlpha(0.2));
  g.drawRoundedRectangle (0,0, getWidth(), getHeight(),20,2);
 }
 void chubber(Chubbalyzer * c) {}
 void printar(FileOutputStream * f) {
  GutsLabel * gg = static_cast<GutsLabel*>(withme);
  String tarno = gg->getText().trimCharactersAtEnd ("\n\r");
  //printf("bubbletarn%s\n",tarno.toUTF8().getAddress());
  if (!tarno.isEmpty()) 
   f->writeText(";" + tarno + "\n",false,false);
  else f->writeText("\n",false,false);
 }
 void colourChanged () {
  withme->setColour(Label::textColourId, findColour(rimma));
  //sub->setColour(Label::textColourId, findColour(rimma));
  repaint();
 }
};

class Poisson : public Seafood {
 public:
 Poisson() : Seafood("Poisson") {
  setColour(haze, Colours::blue);
  withme = new Intestine();
  //withme->addMouseListener(this,0);
  addAndMakeVisible (withme);
  addAndMakeVisible (sub);
  childBoundsChanged (this);//setName("Poisson");
 } //without boolrand is reference copy
 Poisson(Poisson& sg) : Seafood(sg) {
  withme = new Intestine(*static_cast<Intestine*>(sg.withme));//sg.withme);
  //withme->addMouseListener(this,0);
  addAndMakeVisible (withme);
  addAndMakeVisible (sub);
  childBoundsChanged (this);//   setName("Poisson");
  setColour(haze, Colours::blue);
 } 
 Poisson(Poisson& sg, bool rando) : Seafood(sg) {
  
  withme = new Intestine(*static_cast<Intestine*>(sg.withme), rando);//sg.withme);
  //withme->addMouseListener(this,0);
  addAndMakeVisible (withme);
  addAndMakeVisible (sub);
  childBoundsChanged (this);//   setName("Poisson");
  setColour(haze, Colours::blue);
 } 
 ~Poisson() { }
 void paint(Graphics &g) {
  Seafood::paint(g);
  g.setColour (findColour(rimma));
  g.drawRoundedRectangle (0,0, getWidth(), getHeight(),20,2);
 }
 int getNumba() {
  return static_cast<Intestine*>(withme)->getCumulopasty();
 }
 void addGuts(Seafood*g) {
  withme->addAndMakeVisible (g);
 }
 void chubber(Chubbalyzer * c) {
  c->insituate(255);
  static_cast<Intestine*>(withme)->chubberdubber(c);
  c->insituate(0);
 }
 void printar(FileOutputStream * f) {
  f->writeText("(",false,false);
  static_cast<Intestine*>(withme)->printartintar(f);
  f->writeText(")",false,false);
 }
 void colourChanged () {
  sub->setColour(Label::textColourId, findColour(rimma));
  repaint();
 }
 static Seafood * fillPoisson(String & ss) {
  Poisson * si = new Poisson();
  //Parzer::trimComments(ss);
  Parzer::trimma(ss);
  while(!ss.startsWith(")")) {
   si->addGuts(parze(ss));
   //Parzer::trimComments(ss);
   Parzer::trimma(ss);
   //ss = Parzer::trimComments(ss);
  } ss = ss.substring(1);
  return si;
 }
 static Seafood * getHeady(String & ss) {
  String sss;
  Parzer::trimComments(ss);
  String alphstrin = String("abcdefghijklmnopqrstuvwxyz");
  //String alphcandi = ss.initialSectionContainingOnly(alphstrin);
  while(!ss.startsWith("]")) {
   String alphcandi = ss.initialSectionContainingOnly(alphstrin);
   ss = ss.substring(alphcandi.length());
   sss.append(alphcandi,alphcandi.length());
   Parzer::trimComments(ss);
  } ss = ss.substring(1);
  return new Fishgut(sss);
 }
 static Seafood * parze(String & ss) {
  Seafood * si;
  String brakstrin = String("\n\r");
  
  //if (ss.startsWith ("\r")) 
  //printf("rewline\n");
  //if (ss.startsWith ("\n")) {
  String brakcandi = ss.initialSectionContainingOnly(brakstrin);
  if (!brakcandi.isEmpty()) {
   ss = ss.substring(brakcandi.length());
   //printf("newline\n");
   //ss = ss.substring(1);
   return new Bubble();
  }
  if (ss.startsWith(";")) {
   int toWhere = ss.indexOfAnyOf("\n\r"); 
   String poop = ss.substring(0,toWhere);
   ss = ss.substring(toWhere+1);
   ss = ss.trimCharactersAtStart("\n\r");
   return new Bubble(poop);
  } 
  //Parzer::trimComments(ss);
  Parzer::trimma(ss);
  //return new Fishgut(numcandi);
  String numstrin = String("+-0123456789");
  String numcandi = ss.initialSectionContainingOnly(numstrin);
  if (!numcandi.isEmpty()) {
   ss = ss.substring(numcandi.length());
   return new Fishgut(numcandi);
  } 
  String alphstrin = String("abcdefghijklmnopqrstuvwxyz");
  String alphcandi = ss.initialSectionContainingOnly(alphstrin);
  if (!alphcandi.isEmpty()) {
   ss = ss.substring(alphcandi.length());
   return new Fishgut(alphcandi);
  }
  if (ss.startsWith("[")) {
   ss = ss.substring(1);
   return getHeady(ss);
  }
  
  if (ss.startsWith("(")) {
   ss = ss.substring(1);
   return fillPoisson(ss);
  } 
  return nullptr;
  //return parze(ss);
 }  
 void childrenChanged () { 
  childBoundsChanged(this);
  Intestine * inter = static_cast<Intestine*>(withme);
  if (inter->getHedskul()) { 
   liverColour(inter->getHedskul()->getNumba()); repaint();
  }
  if (getParentComponent()) getParentComponent()->childrenChanged(); 
 }
};

Component * Skul::getFlesh() {
 Poisson * holder = new Poisson();
 holder->addGuts(new Fishgut(this, iter++));
 for (int i = 0; i < getGillCount(); i++) 
  holder->addGuts(new Fishgut());
 return holder;
}

Seafood * Seafood::copyGuts(Seafood* sg, bool rando) {
 if (sg->getName() == "Fishgut") {
  Fishgut * tingo = static_cast<Fishgut*>(sg);
  if (tingo->getSkull()) return new Fishgut(*tingo);
  if (rando && !sg->frozen) return new Fishgut();
  else return new Fishgut(*tingo);
 } else if (sg->getName() == "Bubble") {
  Bubble * tingo = static_cast<Bubble*>(sg);
  return new Bubble(*tingo);
 } else if (sg->getName() == "Poisson") {
  Poisson * tingo = static_cast<Poisson*>(sg);
  if (rando && !sg->frozen) return new Poisson(*tingo, true);
  else return new Poisson(*tingo, false);
 } else return nullptr;
}

class Bouillabaisse : 
 public Intestine, 
 public DragAndDropContainer
 {
 protected:
  //UndoManager undy;
 public:
 Bouillabaisse() : 
  Intestine(), DragAndDropContainer()  {}  
 void resized() {}
 void copyEdito() {
  copyBuffa.deselectAll();
  int selectro = Seafood::cowboySmall.getNumSelected ();
  for (int i = 0; i < selectro; i++) {
   Seafood* sg = Seafood::cowboySmall.getSelectedItem (i);
   copyBuffa.addToSelection(sg);
  }
 }
 Bouillabaisse(Bouillabaisse& z, bool rando) : Intestine(z, rando) {}
 void inserto(Seafood*sf) {
 // if (!b) return;
  int selectro = Seafood::cowboySmall.getNumSelected (); 
  UndoableAction * scooty = nullptr;
  mastroUndoicus->beginNewTransaction();
  if (selectro) {
   Seafood*whom = Seafood::cowboySmall.getSelectedItem (selectro-1);
   scooty = new FudgeAction(sf,whom);
  } else 
   scooty = new PutinAction(sf,this);
  mastroUndoicus->perform (scooty);
 }

 void pasteEdito() {
  UndoableAction * scooty = nullptr;
  int celectro = copyBuffa.getNumSelected ();
  if (!celectro) return;
  int selectro = Seafood::cowboySmall.getNumSelected (); 
  mastroUndoicus->beginNewTransaction();
  for (int i = 0; i < celectro; i++) {
   Seafood*who = copyBuffa.getSelectedItem (i);
   if (selectro) {
    Seafood*whom = Seafood::cowboySmall.getSelectedItem (selectro-1);
    scooty = new FudgeAction(Seafood::copyGuts(who,false),whom);
   } else 
    scooty = new PutinAction(Seafood::copyGuts(who,false),this);
   mastroUndoicus->perform (scooty);
  } 
  Seafood::cowboySmall.deselectAll();
 }
 void dupEdito (bool rando) {
  UndoableAction * scooty = nullptr;
  int selectro = Seafood::cowboySmall.getNumSelected (); 
  if (!selectro) return;
  mastroUndoicus->beginNewTransaction();
  for (int i = 0; i < selectro; i++) {
   Seafood*who = Seafood::cowboySmall.getSelectedItem (i);
   scooty = new FudgeAction(Seafood::copyGuts(who,rando),who);
   mastroUndoicus->perform (scooty);
  } 
 } 
 void dupEditoRef() {
  UndoableAction * scooty = nullptr;
  int selectro = Seafood::cowboySmall.getNumSelected (); 
  if (!selectro) return;
  mastroUndoicus->beginNewTransaction();
  for (int i = 0; i < selectro; i++) {
   Seafood*who = Seafood::cowboySmall.getSelectedItem (i);
   if (who->getName() == "Poisson") {
    Poisson * tingo = static_cast<Poisson*>(who);
    scooty = new FudgeAction(new Poisson(*tingo),who);
    mastroUndoicus->perform (scooty);
   }
  } 
 } 

 void cutEdito() {
  copyBuffa.deselectAll();
  int selectro = Seafood::cowboySmall.getNumSelected ();
  if (selectro) mastroUndoicus->beginNewTransaction ();
  else return;
  for (int i = 0; i < selectro; i++) {
   Seafood* sg = Seafood::cowboySmall.getSelectedItem (i);
   copyBuffa.addToSelection(sg);
   TakeAction* takey = new TakeAction(sg);
   mastroUndoicus->perform (takey);
  }
 }
 void deleteEdito() {
  int selectro = Seafood::cowboySmall.getNumSelected ();
  if (selectro) mastroUndoicus->beginNewTransaction ();
  else return;
  for (int i = 0; i < selectro; i++) {
   Seafood* sg = Seafood::cowboySmall.getSelectedItem (i);
   TakeAction* takey = new TakeAction(sg);
   mastroUndoicus->perform (takey);
  } 
 }
 ~Bouillabaisse() {}
 static Bouillabaisse* parze(String& ss) {
  Bouillabaisse * zits = new Bouillabaisse();
  
  while (!ss.startsWith("}") && !ss.isEmpty()) {
   Seafood * s = Poisson::parze(ss);
   if (s)
    zits->addAndMakeVisible(s);
   else ss = ss.substring(1);
   Parzer::trimma(ss);
  } ss = ss.substring(1);
  return zits;
 }
 void chubberdubber(Chubbalyzer * chb) {
  chb->situatier();
  int childro = getNumChildComponents ();
  for (int i = 0; i < childro; i++) {
   Component* c = getChildComponent (i);
   Seafood * g = static_cast<Seafood*>(c);
   g->chubber(chb);
  } chb->insituate(0);
 }
 void printartintar(FileOutputStream * f) {
  f->writeText("{",false,false);
  int childro = getNumChildComponents ();
  for (int i = 0; i < childro; i++) {
   Component* c = getChildComponent (i);
   Seafood * g = dynamic_cast<Seafood*>(c);
   if (g!= nullptr) g->printar(f);
  }
  f->writeText("}",false,false);
 }
 void childrenChanged () {
  Intestine::childrenChanged();
 }
 void itemDropped (const SourceDetails &sd) { 
  Component * f = sd.sourceComponent.get();
  if  (f == this || f->isParentOf(this)) return; 
  mastroUndoicus->beginNewTransaction();
  mastroUndoicus->perform(new PutinAction(f,this));
 }
 void printImago(const String&s) {
  String ss = s + String(".png",4);
  //(s + String(".png")).unquoted()
  FileChooser chooser ("Choose image to save",File (ss),"*.png");
  if (chooser.browseForFileToSave (true)) {
   File imageFile = chooser.getResult ();
   if (imageFile.existsAsFile ())
    imageFile.deleteFile ();
   imageFile.create ();
   PNGImageFormat * pingu = new PNGImageFormat();
   Image imago; 
   imago = createComponentSnapshot (getLocalBounds());
   FileOutputStream* fos = imageFile.createOutputStream ();
   pingu->writeImageToStream (imago,*fos);
   fos->flush();
   delete (fos);
   delete (pingu);
  }
 }
};

