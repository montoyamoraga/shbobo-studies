#ifndef __LABELSKULL__
#define __LABELSKULL__
#include "../JuceLibraryCode/JuceHeader.h"


class RibsLabel : public SizeLabel {
 public:
 RibsLabel(const String &texto) : SizeLabel(texto) {   
  Font f = getFont();
  f.setItalic(true);
  setFont(f);
  setGoodSize();
 }
 void setText(const String &newText) {
  Label::setText(newText,dontSendNotification); setGoodSize();
 }
};

class Skul : public Component, public TooltipClient {
 protected:
 String skull;
 String toolt;
 Font f;
 StringArray args;
 int basenum;
 int limitor;
 int iter;
 public:
 Skul(String sk, String ar, int num, int lim, String tooltip)  {
  skull = sk;
  toolt = tooltip;
  iter = 0;
  args.addTokens(ar, " ", "");
  basenum = num;
  limitor = lim;
  setName("Skul");
  setVisible(true);
  setSize(100,20);
 }
 String getTooltip() { return toolt; }
 String getSkull() const { return skull; }
 String getName(int spoon) const {
  char dongo = 'a' + spoon;
  if (spoon) {
   String appendo = String::charToString(dongo);
   return skull + appendo;
  } else return skull;
 }
 int getNum() const {return basenum;}
 String getRib(int ind) const { return args[ind-1]; }
 int getRibCount() const { return args.size(); }
 int getGillCount() const {
  if (args.indexOf ("mul") >= 0)
   return args.indexOf ("mul");
  else if (args.indexOf ("liszt") >= 0)
   return args.indexOf ("liszt");
  return getRibCount();
 }
 void processSpoon(int&i) const {
  i %= limitor;
 }
 Component * getFlesh(); 
 void paint(Graphics &g) {
  g.setColour (Colours::white);
  g.fillRoundedRectangle (1,1, getWidth()-1, getHeight()-1,5);
  g.setColour(Colours::black);
  if (limitor == 1)
   g.drawSingleLineText(skull,5,getHeight()/2);
  else
   g.drawSingleLineText(skull+" "+String(limitor),5,getHeight()/2);
  int wido = getWidth()-5;
  int hido = 5;
 }
 void mouseDrag(const MouseEvent &evnt) {
  DragAndDropContainer* dragC = 
  DragAndDropContainer::findParentDragContainerFor(this);
  if (!dragC->isDragAndDropActive()) {
   dragC->startDragging(var("flesh") ,getFlesh(),Image::null, true );
   //dragC->startDragging(var("flesh") ,this,Image::null, true );
  }
 }
};

#include <map>

class Calanque : public Component, public DragAndDropContainer {
 std::map<String,Skul*> mymap;
 std::map<int,Skul*> urmap;
public:
 Calanque() :  Component() {
  setSize(100,400);
  Skul * saintePierre;
#define MEXPTOKE(a,b,c,d,e) \
  saintePierre = new Skul(a,b,d,e,c); \
  mymap[a] = saintePierre; \
  urmap[d] = saintePierre; \
  addAndMakeVisible(saintePierre);
  
#include "juliaTokes.def"
  //setBoundsInset (BorderSize<int>(20,20,20,20));
 }
 Skul * getSkul(const String& keyo) {
  return mymap[keyo];
 } 
 void childrenChanged () { 
  int childro = getNumChildComponents ();
  int wido = 0;
  int hido = 0;
  for (int i = 0; i < childro; i++) {
   Component* c = getChildComponent (i);
   if (hido > getHeight() - 20) {
    wido += 100; hido = 0;
   } c->setTopLeftPosition(wido,hido);
   hido += c->getHeight();
  }
 } 
 void resized () { childrenChanged (); }
};

Calanque * standardo;

class GoneFishing : public ResizableWindow {
public:
 GoneFishing() : ResizableWindow("Toolbar",false) {
  Component::addToDesktop (getDesktopWindowStyleFlags());
  setResizable(true, true);
  standardo = new Calanque();
  standardo->addMouseListener(this,0);
  setContentNonOwned(standardo,true);
  centreWithSize (100,400);
  setVisible (true);
  
  //TopLevelWindow::addToDesktop(ComponentPeer::windowIsResizable);
  //setAlwaysOnTop(true);
 }
 int getDesktopWindowStyleFlags() {
  return ComponentPeer::windowIsResizable;
 }

 //BorderSize<int> getContentComponentBorder () {
 // return BorderSize<int>(20,20,20,20); }
 BorderSize<int> getBorderThickness () {
  return BorderSize<int>(20,20,20,20); }
};

class Parzer {
public:
 static void trimComments( String & ss) {
  //ss = ss.trim();
  ss = ss.trimCharactersAtStart(" ");
  while (ss.startsWith(";")) {
   int toWhere = ss.indexOfAnyOf("\n\r");   
   ss = ss.substring(toWhere);
   ss = ss.trimCharactersAtStart(" ");
  } 
 }
 static void trimma( String & ss) {
  //ss = ss.trim();
  ss = ss.trimCharactersAtStart(" \t");

 }
};
  
#endif


