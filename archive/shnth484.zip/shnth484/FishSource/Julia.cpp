#include "../JuceLibraryCode/JuceHeader.h"

class SizeLabel : public Label {
public:
	SizeLabel(const String &texto) : Label("Label", texto) {
		setName("Label");
	} SizeLabel() : Label() {
		
	}
	void setGoodSize() {
		setSize(getWido(),getHido());
	}
	int getWido() {
		Font f = getFont ();
		return f.getStringWidth(getText())+getHorizontalBorderSize()+getHorizontalBorderSize(); 
	}
	int getHido() {
		Font f = getFont ();
		return f.getHeight()+getVerticalBorderSize()+getVerticalBorderSize(); 
	}
	void setText(const String &newText) {
		Label::setText(newText,dontSendNotification); setGoodSize();
  }
};



#include "Chubagwonzer.h"
#include "Bouillabaisse.cpp"
#include "JuliaTabs.cpp"

class JuliaWindow  : public DocumentWindow {
public:
 static Array <JuliaWindow* > juliaz;
 JuliaTabs * sitsz;
 JuliaWindow() ;
 ~JuliaWindow() ;
 void closeButtonPressed();
};
Array <JuliaWindow* > JuliaWindow::juliaz;

#include "JuliaMenu.cpp"  
LookAndFeel lokfeel;

class JuliaChild : public JuliaTabs, public JuliaMenu {
 protected:
 File currentFile;
 File currentBinar;
 public:
 JuliaChild() : 
  JuliaTabs (), JuliaMenu() { 
  //addCrock("bb", new Bouillabaisse());
  currentBinar = File::nonexistent;
  currentFile = File::nonexistent;
 }
 ~JuliaChild() { clearCrocks(); }
 void moveToCurl(String & ss) {
  while (!ss.startsWith("{") && !ss.isEmpty()) {
   ss = ss.substring(1);
  }
 }
 void parze(String & ss) {
  clearCrocks();
  printf("paring\n");
  //JuliaChild * sz = new JuliaChild();
  //Parzer::trimComments(ss);
  ss = ss.trim();
  String namo = " ";
  while (!ss.startsWith("{") && !ss.startsWith(";") && !ss.isEmpty()) {
   ss = ss.substring(1);
  }
  if (ss.startsWith(";")) {
   int toWhere = ss.indexOfAnyOf("\n\r"); 
   namo = ss.substring(1,toWhere);
  }
  moveToCurl(ss);
  while (ss.startsWith("{")) {
   
   ss = ss.substring(1);
   Bouillabaisse * c = Bouillabaisse::parze(ss);
   addCrock(namo, c);
   //Parzer::trimComments(ss);
   ss = ss.trim();
   namo = " ";
   if (ss.startsWith(";")) {
    int toWhere = ss.indexOfAnyOf("\n\r{"); 
    namo = ss.substring(1,toWhere);
   }
   moveToCurl(ss);
  } //return sz; 
  setCurrentCrock(0);
 }
 void newFile() {
  JuliaWindow::juliaz.add(new JuliaWindow());
 }
 void chubberdubber() {
  Chubbalyzer * chb = new Chubbalyzer(nullptr);
  chubdub(chb);
  chb->runThread(); printf("\n");
  delete(chb);
 }
 void chubberdubbertab() {
  Chubbalyzer * chb = new Chubbalyzer(nullptr);
  //chb->insituate(69);
  if (getBroth(getCurrentCrock())) 
   getBroth(getCurrentCrock())->chubberdubber(chb);
  for (int i = 0; i < 16; i++) {
   chb->insituate(0);
  } 
  chb->runThread(); printf("\n");
  delete(chb);
 }
 void chubdub(Chubbalyzer * chb) {  
  //chb->insituate(69);
  int childro = getNumCrocks ();
  for (int i = 0; i < childro; i++) {
   getBroth(i)->chubberdubber(chb);
  } 
  for (int i = 0; i < 16; i++) {
   chb->insituate(0);
  }
 }
 void uploadBinar() {
  FileChooser chooser ("Choose file to open",currentBinar.getParentDirectory(),"*.bin");
  if (chooser.browseForFileToOpen ()) {
   currentBinar = chooser.getResult ();
   Chubbalyzer * chb = new Chubbalyzer(currentBinar.getFullPathName().toUTF8());
   chubdub(chb);
   chb->runThread(); printf("\n");
   delete(chb);
  }
 }
 void gwonzero() {
  Chubagwonzer::showGwonz();
 }
 
 void openFileInEditor () {
  //String ss;
  if (currentFile.existsAsFile ()) {
   String ss = currentFile.loadFileAsString();
   parze (ss);
  }
 }
 void chooseFileToOpen () {
  FileChooser chooser ("Choose file to open",currentFile.getParentDirectory(),"*.txt");
  if (chooser.browseForFileToOpen ()) {
   currentFile = chooser.getResult ();
   openFileInEditor ();
   JuliaWindow * jw = dynamic_cast<JuliaWindow*>(getParentComponent());
   if (jw) 
    jw->setName("Fish: " + currentFile.getFileName());
  }
 }
 void saveFileFromEditor () {
  if (currentFile == File::nonexistent) {
   chooseFileToSave () ;
   return;
  }
  if (currentFile.existsAsFile ())
   currentFile.deleteFile ();
  currentFile.create ();
  FileOutputStream * fos = currentFile.createOutputStream();
  printtar(fos);
  fos->flush();
  delete(fos);
 }
 void printtar(FileOutputStream * f) {  
  //f->writeText("0",false,false);
  int childro = getNumCrocks ();
  for (int i = 0; i < childro; i++) {
   //printf("savfingchildro\n");
   String ss = getCrockName(i);
   f->writeText(";",false,false);
   f->writeText(ss,false,false);
   f->writeText("\n",false,false);
   getBroth(i)->printartintar(f);
  } 
 }
 void chooseFileToSave () {
  FileChooser chooser ("Choose file to save",File::nonexistent,"*.txt");
  if (chooser.browseForFileToSave (true)) {
   currentFile = chooser.getResult ();
   saveFileFromEditor ();
  }
 }
 void inserto (Seafood*sf) {
  getBroth (getCurrentCrock())->inserto(sf);
 }
 void copyEdito() {
  getBroth (getCurrentCrock())->copyEdito();
 }
 void cutEdito() {
  getBroth (getCurrentCrock())->cutEdito();
 }
 void pasteEdito() {
  getBroth (getCurrentCrock())->pasteEdito();
 }
  void dupEdito() {
  getBroth (getCurrentCrock())->dupEdito(false);
 }
   void dupEditoRef() {
  getBroth (getCurrentCrock())->dupEditoRef();
 }
  void randupEdito() {
  getBroth (getCurrentCrock())->dupEdito(true);
 }
 void deleteEdito() {
  getBroth (getCurrentCrock())->deleteEdito();
 }
 void undoEdito() {
  mastroUndoicus->undo();
 }
 void redoEdito() {
  mastroUndoicus->redo();
 }
 void printoBouillo () {
  String ss = getCurrentCrockName();
  getBroth (getCurrentCrock())->printImago(ss);
 }

 void bouillabaisseNew(){
  addCrock("bb",new Bouillabaisse());}

 void bouillabaisseDup(){
  if (getCurrentCrock () == -1) return; 
   String ss = getCurrentCrockName();
  if (getBroth (getCurrentCrock())) 
   addCrock(ss,new Bouillabaisse(*getBroth (getCurrentCrock()),false));}

 String randostring(const String&ss) {
  int len = ss.length();
  String newstring (ss);
  for (int i = 0; i < len; i++) {
   int randh = rand() % len;
   newstring = String(newstring.substring(0,randh) + newstring.getLastCharacters(1) + newstring.substring(randh,len-1));
   
  } return newstring;
 }
 void bouillabaisseRandup(){
  if (getCurrentCrock () == -1) return; 
   String ss = randostring (
 	getCurrentCrockName());

  if (getBroth (getCurrentCrock()))
   addCrock(ss,new Bouillabaisse(*getBroth (getCurrentCrock()),true));
 }
 void bouillabaisseRandupDotDotDot(){
  Label labia("randuplabel","1");
  labia.setVisible(true);
	 labia.setEditable(true);
	 labia.setSize(200,100);
  DialogWindow::showModalDialog ("How many times to randuplicate?",
                            &labia, nullptr,Colours::grey,
                            true);
  int timesz = labia.getText().getIntValue();
  for (int i = 0; i < timesz; i++) {
   if (getCurrentCrock () == -1) return; 
   String ss = randostring (
    getCurrentCrockName());
   if (getBroth (getCurrentCrock()))
    addCrock(ss,new Bouillabaisse(*getBroth (getCurrentCrock()),true));
  }
 }
 void barcodero() {
  Label labia("barcodelabel",String(mastroBarcode));
  labia.setVisible(true);
	 labia.setEditable(true);
  labia.setSize(200,100);
  DialogWindow::showModalDialog ("Barcode",
   &labia, nullptr,Colours::grey,
   true);
  mastroBarcode = labia.getText().getIntValue();
 }
	
	
 void bouillabaisseDel(){
  //int hh = getCurrentCrock();
  removeCrock(getCurrentCrock()); 
  //setCurrentCrock(hh-1);
 }
 void bouillabaisseBW(){
  if (bwMode) {
   bwMode = false;
   LookAndFeel::setDefaultLookAndFeel (nullptr);
  } else {
   bwMode = true;
   LookAndFeel::setDefaultLookAndFeel (&lokfeel);
  }
 }
	
	void tooltipToggle(){
		if (tooltipMode) {
			tooltipMode = false;
			if (ttw) delete(ttw);
				ttw  = nullptr;
		} else {
			tooltipMode = true;
			ttw = new TooltipWindow();
		}
	}
};


JuliaWindow::JuliaWindow() : DocumentWindow ("Fish by Shbobo",
      Colours::lightgrey, DocumentWindow::allButtons,
      true) {
 JuliaChild * sits;   
 sits = new JuliaChild();
 sitsz = sits;
 setResizable(true, true);
 addKeyListener(sits->commandManager->getKeyMappings());
 setContentOwned(sits,true);
 centreWithSize (400,400);
 setMenuBar(sits);
 setVisible (true);
}
JuliaWindow::~JuliaWindow() {delete (sitsz);}
void JuliaWindow::closeButtonPressed() {
 if (juliaz.size() == 1)
 JUCEApplication::quit();
 else{juliaz.remove( juliaz.indexOf(this)); delete(this);}
} 
